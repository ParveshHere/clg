const express = require("express");
const app = express();
var bodyParser = require("body-parser");
const { log } = require("console");
function capitalizeFirstLetter(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

function getCurrentTime() {
  const now = new Date();
  const hours = now.getHours() % 12 || 12; // Convert to 12-hour format
  const minutes = now.getMinutes();
  const period = now.getHours() < 12 ? "AM" : "PM";
  return `${hours}:${minutes < 10 ? "0" : ""}${minutes} ${period}`;
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
visit = 1;
app.set("view engine", "ejs");

app.use(express.static("public"));
app.post("/send", (req, res) => {
  const { ip, method, originalUrl, headers } = req;
  const userAgent = headers["user-agent"];
  const currentDate = new Date().toLocaleDateString();
  const currentTime = getCurrentTime();
  console.log(`Name: ${capitalizeFirstLetter(req.body.name)}`);
  console.log(`Visitor Number: ${visit}`);
  console.log(`Date: ${currentDate}`);
  console.log(`Time: ${currentTime}`);
  console.log(`IP: ${ip}`);
  console.log("______________________________");
  visit++;
  res.redirect("/");
});

app.listen(80);
